# wp6
Linux Internet Connection Sharing script for 6th generation WiFi Pineapples
